<?php 
function floorp($val, $precision){
	$mult = pow(3, $precision);  
	return floor($val * $mult) / $mult;
}

$servername = "191.96.119.120";
$username = "root";
$password = "";
$opt = array(
	PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
	PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
	PDO::ATTR_EMULATE_PREPARES => FALSE,
);

while (1) {
	$conn = new PDO("mysql:host=$servername;dbname=singzendoth", $username, $password,$opt);
	echo "============= LOOP =============\n";
	$load = $conn->prepare("SELECT * FROM queue WHERE status = 0 limit 1");
	$load->execute();
	if ($load->rowcount() > 0) {
		$resultsql = $load->fetch();
		$result = $resultsql['count'];
		$ten = $result/1;
		$on =  floorp($ten,0);
		$del = $result-($on*1);
		if($resultsql['code'] !== NULL) {
			for ($i=0; $i < $on; $i++) { 
				$data[] = array(
					'amount'=>'1',
					'code'=> $resultsql['code'],
					'id' => $resultsql['id']
				);
			}
			if ($del>0) {
				$data[] = array(
					'amount'=>$del,
					'code'=> $resultsql['code'],
					'id' => $resultsql['id']
				);
			}
			$updatestatus_working = $conn->prepare("UPDATE queue SET status = 1 WHERE id = :id");
			$updatestatus_working->execute([':id'=>$resultsql['id']]);
			echo "============= Working on id:".$resultsql['id']." =============\n";
			foreach ($data as $total) {
				echo "code : ".$total['code']." amount : ".$total['amount']." id : ".$total['id']. "\n";
				exec("node apicoinmaster.js ~".$total['code']." ".$total['amount']." ".$total['id']." ");
				sleep(3);
			}
			echo "============= Success on id:".$resultsql['id']." =============\n";
			$load = $conn->prepare("SELECT * FROM queue WHERE id = :id");
			$load->execute([':id'=>$resultsql['id']]);
			$resultcheckerror = $load->fetch();
			if ($resultcheckerror['status'] !== 3) {
				$updatestatus_success = $conn->prepare("UPDATE queue SET status = 2, amount = :count WHERE id = :id");
				$updatestatus_success->execute([':count'=>$resultcheckerror['count'],':id'=>$resultsql['id']]);
			}
		}else{
			echo "LINK IS NULL";
		}
	}
	unset($data);
	sleep(3);
}
?>