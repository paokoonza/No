const nameshop = "Ds-Shop";
const axios = require("axios-https-proxy-fix");
const uuid = require('uuid-random');
const cluster = require('cluster');
const HttpsProxyAgent = require('https-proxy-agent');
const { exit } = require("process");
fs = require('fs');
Array.prototype.random = function () {
	return this[Math.floor((Math.random()*this.length))];
}
var mysql = require('mysql');
var con = mysql.createConnection({
	host: "191.96.119.120",
	user: "root",
	password: "",
	database: "singzendoth"
});
function Logindata(devicetoken){
	return {
		"Expect": "100-continue",
		"Connection": "keep-alive",
		"X-CLIENT-VERSION": "3.5.220",
		"Cookie": "cme=global;",
		"Content-Type": "application/x-www-form-urlencoded",
		"Authorization": "Bearer " + devicetoken,
		"Host": "vik-game.moonactive.net"};
	}

	function Registerdata(){
		return {
			"Expect": "100-continue",
			"Connection": "keep-alive",
			"Host": "vik-game.moonactive.net"
			// "X-PLATFORM" : "Android",
			// "User-Agent" : "Dalvik/2.1.0 (Linux; U; Android 5.1.1; SM-G955N Build/NRD90M.G955NKSU1AQDC)",
		};
	}

	function getRandomInt(max) {
		return Math.floor(Math.random() * Math.floor(max));
	}
	function readmammoz(){
		return fs.readFileSync('mammoz.txt','utf8');
	}

	var data = fs.readFileSync('token.txt', 'UTF-8');
    const gettokenurl = data.split(/\r?\n/);
    const randomarray = getRandomInt(gettokenurl.length);
    var tokenget = gettokenurl[randomarray];
    var tokenusez = tokenget.replace(" ", "");
    console.log(tokenusez)
	async function gettokenfb(invitation){ 
		await axios("https://graph.facebook.com/149800446846047/accounts/test-users?access_token="+gettokenurl.random()+"&installed=true&name="+nameshop+"&permissions=read_stream&method=post")
    .then(function (response) {
			if (response.data.access_token == "") {
				return gettokenfb(invitation);
			}else{
				token = response.data.access_token
				token_id = response.data.id

				con.connect(function(err) {
					var sql = "SELECT * FROM auth1 WHERE mmppoo = 2 LIMIT 1";
					con.query(sql, function (err, result) {
					  Object.keys(result).forEach(function(mmppoo) {
						var row = result[mmppoo];
						  console.log(row);
						  idd = row.id;
						  deviceTokenn = row.deviceToken;
						  deviceIdd = row.deviceId;
						  console.log(deviceTokenn);
						  console.log(deviceIdd);

						  con.connect(function(err) {
							var lll = "UPDATE auth1 SET mmppoo = 1 WHERE id = ?";
							con.query(lll,[idd], function (err, result) {
							});
						});
				Login(token_id,deviceIdd,deviceTokenn,token,invitation)
			});
			});
		});
			}
		})
		.catch(function (error) {
			console.log(error);
			return gettokenfb(invitation);
		})
	};
	async function deletetokenfb(token_id,access_token){ 
		await axios("https://graph.facebook.com/"+token_id+"?method=delete&access_token="+access_token).then(function (response) {
      if (response.status == 200) {
				console.log("Delete Token Facebook Success");
			} else {
				return deletetokenfb(token_id,access_token);
			}
		}).catch(function (error) {
			console.log(error);
			return deletetokenfb(token_id,access_token);
		})
	};

	async function Login(token_id,deviceID,deviceToken,fbtoken,invitation){
		var datagame = "Device%5budid%5d="+deviceID+"&API_KEY=viki&API_SECRET=coin&Client%5bversion%5d=3.5_fband&Device%5bchange%5d=20201105_5&fbToken=&seq=0";
		var logindata = Logindata(deviceToken);
		await axios({
			method: 'post',
			url: 'https://vik-game.moonactive.net/api/v1/users/login',
			data: datagame,
			headers: logindata,

		}).then(function (response) {
			var res = {"deviceID": deviceID,
			"info": {
				"change_timestamp":response.data.change_timestamp,
				"profile":response.data.profile,
				"sessionToken":response.data.sessionToken,
				"userId":response.data.userId
			}           
		}
		Loginfbgame(token_id,res.deviceID,res.info.sessionToken,res.info.userId,fbtoken,res,invitation)
	}).catch(function (error) {
		console.log(error);
		exit();
	});
}
async function Loginfbgame(token_id,deviceID,sessionToken,userid,fbtoken,res,invitation){
	var logindata = Logindata(sessionToken);
	var datagame = "Device%5budid%5d="+deviceID+"&API_KEY=viki&API_SECRET=coin&User%5bfb_token%5d="+fbtoken+"&p=fb&Client%5bversion%5d=3.5.191_fband&Device%5bchange%5d=20201105_5";
	await axios({
		method: 'post',
		url: 'https://vik-game.moonactive.net/api/v1/users/' + userid + "/update_fb_data",
		data: datagame,
		headers: logindata,

	}).then(function (response) {
		deletetokenfb(token_id,fbtoken)
		startaccept_invitation(deviceID,sessionToken,response.data.userId,response.data.fbToken,invitation)
	}).catch(function (error) {
		console.log(error);
		return gettokenfb(invitation);
	});
}
async function startaccept_invitation(deviceID,sessionToken,userid,fbtoken,invitation){
	var logindata = Logindata(sessionToken);
	var dataaccept_invitation = "Device%5budid%5d="+deviceID+"&API_KEY=viki&API_SECRET=coin&Device%5bchange%5d=20201225&fbToken="+fbtoken+"&locale=th&inviter="+invitation;
	await axios({
		method: 'post',
		url: 'https://vik-game.moonactive.net/api/v1/users/' + userid + "/accept_invitation",
		data: dataaccept_invitation,
		headers: logindata,
	}).then(async function (response) {
		console.log("ADDSPIN TO: ",response.data.name)
		id = process.argv[4];
		var sql = "UPDATE queue SET facebookname = ? WHERE id = ?";
    con.query(sql,[ response.data.name,id ], function (err, result) {
      if (err) throw err;
      console.log("GETNAME TO MYSQL SUCCESS");
    });
  startspin(sessionToken,deviceID,fbtoken,userid,invitation);
  }).catch(function (response) { 
  	id = process.argv[4];
  	nameerror = "ERROR";
  	var sql = "UPDATE queue SET facebookname = ? , status = 'error' WHERE id = ?";
    con.query(sql,[ nameerror,id ],function (err, result) {
      if (err) throw err;
      console.log("ERROR2");
      id = process.argv[4];
      var sqlshow = "SELECT * FROM queue WHERE id = ?";
      con.query(sqlshow,[ id ],function (err, result) {
        Object.keys(result).forEach(function(id) {
          var row = result[id];
          usernameid = row.username;
          var sqlshow = "SELECT * FROM users WHERE username = ?";
          con.query(sqlshow,[ usernameid ],function (err, result) {
            Object.keys(result).forEach(function(id) {
              var row = result[id];
              var sqlz = "UPDATE users SET point = point+1 WHERE username = ?";
              con.query(sqlz,[ row.username ],function (err, result) {
                if (err) throw err;
                console.log("Point+1 !!");
                process.exit();
              });
            });
          });
        });
      });
    });
});
}
async function startspin(sessionToken,deviceID,fbtoken,userid,invitation){
	var logindata = Logindata(sessionToken);
	coun = 1;
	for ($i=0; $i < 18; $i++) { 
		coun++;
		dataspin = "Device%5budid%5d="+deviceID+"&API_KEY=viki&API_SECRET=coin&Device%5bchange%5d=20201105_4&fbToken="+fbtoken+"&locale=en&seq="+coun+"&auto_spin=False&bet=1&Client%5bversion%5d=3.5.210_fband";
		await axios({
			method: 'post',
			url: 'https://vik-game.moonactive.net/api/v1/users/' + userid + "/spin",
			data: dataspin,
			headers: logindata,
		}).then(function (response) {
		}).catch(function (error) {
			console.log(error);
		});
	}
	id = process.argv[4];
	var sqlz = "UPDATE queue SET amount = amount+1 WHERE id = ?";
  con.query(sqlz,[ id ],function (err, result) {
    console.log("AMOUNT+1 !!");
    if (err) throw err;
  });
  startupgread2(sessionToken,deviceID,fbtoken,userid,invitation)
}
async function startupgread2(sessionToken,deviceID,fbtoken,userid,invitation){
	var teerawat = process.argv[2];
	var bossnzxdz3 = teerawat.replace('~','');
	console.log(bossnzxdz3);
	var teerawatteerawatzdasdasd = invitation.replace('&amp;af_dp=coinmaster%3A%2F%2F&amp;af_web_dp=https%3A%2F%2Fapps.facebook.com%2Fcoin-master%2F&amp;af_sub1='+bossnzxdz3+'&amp;af_sub4=messenger','');
	var logindata = Logindata(sessionToken);
	data4 = "Device%5budid%5d="+deviceID+"&API_KEY=viki&API_SECRET=coin&Device%5bchange%5d=20201105_4&fbToken="+fbtoken+"&locale=th&item=House&state=1&include%5b0%5d=pets";
	data2 = "Device%5budid%5d=" + deviceID + "&API_KEY=viki&API_SECRET=coin&Device%5bchange%5d=20201225_2&fbToken=" + fbtoken + "&locale=th";
	await axios({
		method: 'post',
		url: 'https://vik-game.moonactive.net/api/v1/users/' + userid + "/upgrade",
		data: data4,
		headers: logindata,
	}).then(function (response) {
	}).catch(function (error) {
		console.log(error);
	});

	await axios({
		method: 'post',
		url: 'https://vik-game.moonactive.net/api/v1/users/'+ userid +'/friends/v2/'+bossnzxdz3+'/pending_requests',
		data: data2,
		headers: logindata,
	}).then(function (response) {
		console.log(response.data);
		console.log("PENDING REQUETS");
	});

	await axios({
		method: 'post',
		url: 'https://vik-game.moonactive.net/api/v1/users/'+ userid +'/friends/v2/'+teerawatteerawatzdasdasd+'/approve_request',
		data: data2,
		headers: logindata,
	}).then(function (response) {
		console.log(response.data);
		console.log("APPROVE REQUETS");
	});
	exit();
}
async function main(){
	const invitationurl = process.argv[2],
	count = process.argv[3];
	id = process.argv[4];
	uri = 'https://vik-game.moonactive.net/external/users/' + invitationurl + "/invite?s=m";
	await axios({
		method: 'get',
		url: uri,
	}).then(async function (response) {
		var a = response.data.match(/&amp;c=[^}]*messenger/g);
		console.log(a[0].replace('&amp;c=','').replace('',''));
		if (cluster.isMaster) {
			for (let i = 0; i < count; i++) {
				cluster.fork();
			}
			cluster.on('exit', (worker, code, signal) => {
			});
		} else {
			gettokenfb(a[0].replace('&amp;c=','').replace('',''));
		}
	})
	.catch(async function (error) {
		console.log("error");
		process.exit()
	});
}
main()